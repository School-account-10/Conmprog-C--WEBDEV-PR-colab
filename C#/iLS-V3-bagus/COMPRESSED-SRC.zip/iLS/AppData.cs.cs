﻿namespace iLS
{
    public static class AppData
    {
        public static List<string> History = new List<string>();
    }
}
